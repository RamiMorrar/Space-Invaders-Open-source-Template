﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBulletController : MonoBehaviour
{
    // Start is called before the first frame update

    private Transform bullet;
    public float speed;
    void Start()
    {
        bullet = GetComponent<Transform>();
    }

    void FixedUpdate()
    {
        bullet.position += Vector3.up * -speed;

        if (bullet.position.y <= -10)
        {
            Destroy(gameObject);
        }
    }
    // Update is called once per frame

        void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player"){
            Destroy(gameObject);
            Destroy(other.gameObject);
            Gameover.isplayerdead = true;

        } else if (other.tag == "Base")
        {
            GameObject playerbase = other.gameObject;
            BaseHealth baseHealth = playerbase.GetComponent<BaseHealth>();
            baseHealth.health -= 1;
            Destroy(gameObject);
        }
    }
    void Update()
    {
        
    }
}
