﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseDefeat : MonoBehaviour
{
    private Transform playerbase;
    // Start is called before the first frame update
    void Start()
    {
        playerbase = GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        if (playerbase.childCount == 0)
        {
            Gameover.isplayerdead = true;
        }
    }
}
