﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private Transform player;
    public float speed;
    public float maxbound, minbound;

    public GameObject shot;
    public Transform Shotspawn;
    public float firerate;
    public float nextfire;
    // Start is called before the first frame update
    void Start()
    {
        player = GetComponent<Transform>();

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        float h = Input.GetAxis("Horizontal");

        if (player.position.x < minbound && h < 0)
        {
            h = 0;
        }
        if (player.position.x > maxbound && h > 0)
        {
            h = 0;
        }

        player.position += Vector3.right * h * speed;
    }
    void Update()
    {
        if(Input.GetButton("Fire1") && Time.time > nextfire)
        {
            nextfire = Time.time + firerate;
            Instantiate(shot, Shotspawn.position, Shotspawn.rotation);
        }
    }
}
